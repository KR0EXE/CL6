# LibertyAgent

**LibertyAgent** is a customizable local AI assistant that:
- Monitors user behavior and generates automation ideas
- Executes Python and shell scripts
- Accepts real-time edits through a secure UI approval system
- Communicates with a local GPT model or OpenAI's API

## Features

- 🔁 Log-based behavior pattern detection
- 🤖 GPT-driven code suggestions
- 🖥️ GUI with command input, output, and logs
- 🧠 Self-editing agent (asks for approval before patching itself)
- ☁️ Easy to extend with plugins or new logic modules

## Setup

1. Install Python 3.10+ and required packages:
```bash
pip install openai psutil pyautogui pynput python-dotenv pillow
```

2. Set your API key in `.env`:
```
OPENAI_API_KEY=your-key-here
```

3. Run the agent:
```bash
python LibertyAgent_UI.py
```

4. To allow edits from AI:
```bash
python agent_file_editor.py  # Optional; this can also be embedded in the UI
```

## License

MIT
