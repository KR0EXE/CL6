import time
from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai

print("🟢 Liberty Agent Started. Watching...")

while True:
    log_snapshot()
    logs = load_logs()
    prompt = format_prompt_from_logs(logs)
    print("\n🧠 Prompt Sent to GPT-4:\n", prompt)

    response = query_openai(prompt)
    print("\n🤖 GPT-4 Response:\n", response)

    with open("memory.jsonl", "a") as f:
        f.write(response + "\n")

    time.sleep(30)