import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import os

print("✅ LibertyAgent_MIN starting...")

class LibertyAgentTestUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Liberty Agent - Minimal")
        self.root.geometry("600x400")

        self.status_label = tk.Label(root, text="Agent running...", fg="lime", bg="black")
        self.status_label.pack(fill="x")

        self.response_box = ScrolledText(root, bg="black", fg="white")
        self.response_box.pack(fill="both", expand=True)
        self.response_box.insert(tk.END, "👋 Agent initialized successfully.")

if __name__ == "__main__":
    try:
        print("STEP 1: Tk launch")
        root = tk.Tk()
        print("STEP 2: UI init")
        app = LibertyAgentTestUI(root)
        print("STEP 3: Entering mainloop")
        root.mainloop()
    except Exception as e:
        with open("agent_crashlog.txt", "w") as f:
            f.write(f"[LibertyAgent_MIN] Crash: {str(e)}\n")
