import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import threading
import time
import os
import tkinter.simpledialog as sd
import threading
import json
import os
import time

import json
import os
import time
from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai

QUEUE_FILE = "agent_queue.json"
OUTPUT_FILE = "agent_output.json"

def run_custom_logic(instruction):
    task = instruction.get("task")
    if task == "analyze_recent_activity":
        logs = load_logs()
        prompt = format_prompt_from_logs(logs[-5:])
        response = query_openai(prompt)
        return {"prompt": prompt, "response": response}
    elif task == "say":
        return {"message": instruction.get("message", "No message provided.")}
    else:
        return {"error": "Unknown task"}

def listen_for_instructions():
    print("📡 Agent command listener active.")
    while True:
        if os.path.exists(QUEUE_FILE):
            try:
                with open(QUEUE_FILE, "r") as f:
                    instruction = json.load(f)
                result = run_custom_logic(instruction)
                with open(OUTPUT_FILE, "w") as f:
                    json.dump(result, f, indent=2)
                os.remove(QUEUE_FILE)
            except Exception as e:
                with open(OUTPUT_FILE, "w") as f:
                    json.dump({"error": str(e)}, f)
        time.sleep(5)


from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai
from script_runner import run_script, run_shell
from agent_file_editor import listen_for_file_edits, apply_edit_safely

# Define safe full path for logs
LOG_PATH = os.path.expandvars(r"%LOCALAPPDATA%\\LibertyAgent\\logs\\agent_logs.json")
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

class LibertyAgentUI:

    def handle_edit_prompt(self, edit_data):
        import tkinter.messagebox as mb
        f = edit_data.get("file")
        pattern = edit_data.get("pattern")
        replacement = edit_data.get("replacement")
        if not f or not pattern or not replacement:
            return "Invalid edit request."
        confirm = mb.askyesno("Approve Code Edit", f"Replace this in {f}?\n\n'{pattern}'\n→\n'{replacement}'")
        if confirm:
            result = apply_edit_safely(f, pattern, replacement)
            self.execution_output.insert(tk.END, f"\n[Agent Edit Result]\n{result}\n")
            return result
        else:
            self.execution_output.insert(tk.END, "\nEdit rejected by user.\n")
            return "Edit rejected."
    def __init__(self, root):
        self.root = root
        self.root.title("Liberty Agent - Live Monitor")
        self.root.geometry("800x600")

        # Animated background canvas

        # Overlay frame for UI widgets
        overlay_frame = tk.Frame(self.canvas, bg='#000000', bd=0)
        overlay_frame.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.prompt_box = ScrolledText(overlay_frame, height=10, bg="#1e1e1e", fg="white")
        self.prompt_box.pack(fill="both", expand=False)

        self.response_box = ScrolledText(overlay_frame, bg="black", fg="lime")
        self.response_box.pack(fill="both", expand=True)

        self.status_label = tk.Label(overlay_frame, text="Status: Idle", anchor="w")
        self.status_label.pack(fill="x")

        self.run_button = tk.Button(overlay_frame, text="Run Last Script", command=self.run_last_script)
        self.run_button.pack(fill="x")

        self.shell_button = tk.Button(overlay_frame, text="Run Shell Command", command=self.run_shell_command)
        self.shell_button.pack(fill="x")

        self.execution_output = ScrolledText(overlay_frame, height=8, bg="#111", fg="cyan")
        self.execution_output.pack(fill="both", expand=False)
        self.command_log = ScrolledText(root, height=6, bg="#111", fg="orange")
        self.command_log.pack(fill="both", expand=False)

        self.command_button = tk.Button(overlay_frame, text="Send Agent Command", command=self.send_agent_command)
        self.command_button.pack(fill="x")

    def send_agent_command(self):
        try:
        import tkinter.simpledialog as sd
    import threading
    import json
    import os
    import time
        except Exception as e:
            with open("agent_crashlog.txt", "a") as log:
                log.write(f"[send_agent_command] Error: {str(e)}\n")

import json
import os
import time
from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai

QUEUE_FILE = "agent_queue.json"
OUTPUT_FILE = "agent_output.json"

def run_custom_logic(instruction):
    task = instruction.get("task")
    if task == "analyze_recent_activity":
        logs = load_logs()
        prompt = format_prompt_from_logs(logs[-5:])
        response = query_openai(prompt)
        return {"prompt": prompt, "response": response}
    elif task == "say":
        return {"message": instruction.get("message", "No message provided.")}
    else:
        return {"error": "Unknown task"}

def listen_for_instructions():
    print("📡 Agent command listener active.")
    while True:
        if os.path.exists(QUEUE_FILE):
            try:
                with open(QUEUE_FILE, "r") as f:
                    instruction = json.load(f)
                result = run_custom_logic(instruction)
                with open(OUTPUT_FILE, "w") as f:
                    json.dump(result, f, indent=2)
                os.remove(QUEUE_FILE)
            except Exception as e:
                with open(OUTPUT_FILE, "w") as f:
                    json.dump({"error": str(e)}, f)
        time.sleep(5)


        import json
        import os

        task = sd.askstring("Agent Task", "Enter task type (e.g. analyze_recent_activity or say):")
        if task:
            payload = {"task": task}
            if task == "say":
                msg = sd.askstring("Say", "Message:")
                if msg:
                    payload["message"] = msg

            try:
                with open("agent_queue.json", "w") as f:
                    json.dump(payload, f)
                time.sleep(6)  # wait for listener to respond
                if os.path.exists("agent_output.json"):
                    with open("agent_output.json") as f:
                        result = json.load(f)
                    self.execution_output.insert(tk.END, f"\n>>> Agent Output:\n{json.dumps(result, indent=2)}\n{'-'*80}\n")
                    self.execution_output.see(tk.END)
            except Exception as e:
                self.execution_output.insert(tk.END, f"\n>>> Command Error:\n{str(e)}\n{'-'*80}\n")

        self.run_loop()

    def run_last_script(self):
        self.command_log.insert(tk.END, f"[SCRIPT] Running last script...\n")
        try:
        code = self.response_box.get("1.0", tk.END)
        output = run_script(code)
        self.execution_output.delete("1.0", tk.END)
        self.execution_output.insert(tk.END, output)
        except Exception as e:
            with open("agent_crashlog.txt", "a") as log:
                log.write(f"[run_last_script] Error: {str(e)}\n")

    def run_shell_command(self):
        self.command_log.insert(tk.END, f"[SHELL] Running shell command...\n")
        try:
        command = sd.askstring("Run Shell Command", "Enter a shell command:")
        if command:
            output = run_shell(command)
            self.execution_output.delete("1.0", tk.END)
            self.execution_output.insert(tk.END, output)
        except Exception as e:
            with open("agent_crashlog.txt", "a") as log:
                log.write(f"[run_shell_command] Error: {str(e)}\n")

    def display_message(self, message):
        self.response_box.insert(tk.END, f"\n>>> Message from Liberty Agent:\n{message}\n{'-'*80}\n")
        self.response_box.see(tk.END)

    def run_loop(self):
        try:
        except Exception as e:
            with open("agent_crashlog.txt", "a") as log:
                log.write(f"[run_loop] Error: {str(e)}\n")
        def loop():
            while True:
                log_snapshot(path=LOG_PATH)
                logs = load_logs(path=LOG_PATH)
                prompt = format_prompt_from_logs(logs)
                self.prompt_box.delete("1.0", tk.END)
                self.prompt_box.insert(tk.END, prompt)
                self.status_label.config(text="Status: Querying GPT-4...")

                try:
                    response = query_openai(prompt)
                except Exception as e:
                    response = f"Error: {str(e)}"

                self.response_box.insert(tk.END, f"\n>>> Response @ GPT-4:\n{response}\n{'-'*80}\n")
                self.response_box.see(tk.END)
                self.status_label.config(text="Status: Sleeping... (30s)")
                time.sleep(30)


if __name__ == "__main__":
    threading.Thread(target=lambda: listen_for_file_edits(app.handle_edit_prompt), daemon=True).start()
    threading.Thread(target=lambda: listen_for_file_edits(app.handle_edit_prompt), daemon=True).start()
    print("STEP 1: Tk started")
    root = tk.Tk()
    print("STEP 2: UI Init")
    app = LibertyAgentUI(root)
    print("STEP 3: Listener started")
    threading.Thread(target=listen_for_instructions, daemon=True).start()
    print("STEP 4: Entering mainloop")
    root.mainloop()
try:
except Exception as e:
    with open("agent_crashlog.txt", "a") as f:
        f.write(f"[startup] Fatal error: {str(e)}\n")
    app.display_message("👁️ Agent online. Monitoring your actions and preparing automations.")
