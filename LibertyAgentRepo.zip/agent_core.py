import time, psutil, json
from datetime import datetime
import os

def get_active_window():
    try:
        import pygetwindow as gw
        win = gw.getActiveWindow()
        return win.title if win else None
    except:
        return None

def get_open_processes():
    return [p.name() for p in psutil.process_iter(['name'])]

def log_snapshot(path=None):
    if path is None:
        path = os.path.expandvars(r"%LOCALAPPDATA%\\LibertyAgent\\logs\\agent_logs.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    snapshot = {
        "timestamp": str(datetime.now()),
        "active_window": get_active_window(),
        "open_processes": get_open_processes()
    }
    with open(path, "a") as f:
        f.write(json.dumps(snapshot) + "\n")
