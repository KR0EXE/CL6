import json
import os
import time
from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai

QUEUE_FILE = "agent_queue.json"
OUTPUT_FILE = "agent_output.json"

def run_custom_logic(instruction):
    task = instruction.get("task")
    if task == "analyze_recent_activity":
        logs = load_logs()
        prompt = format_prompt_from_logs(logs[-5:])
        response = query_openai(prompt)
        return {"prompt": prompt, "response": response}
    elif task == "say":
        return {"message": instruction.get("message", "No message provided.")}
    else:
        return {"error": "Unknown task"}

def listen_for_instructions():
    print("📡 Agent command listener active.")
    while True:
        if os.path.exists(QUEUE_FILE):
            try:
                with open(QUEUE_FILE, "r") as f:
                    instruction = json.load(f)
                result = run_custom_logic(instruction)
                with open(OUTPUT_FILE, "w") as f:
                    json.dump(result, f, indent=2)
                os.remove(QUEUE_FILE)
            except Exception as e:
                with open(OUTPUT_FILE, "w") as f:
                    json.dump({"error": str(e)}, f)
        time.sleep(5)

if __name__ == "__main__":
    listen_for_instructions()
