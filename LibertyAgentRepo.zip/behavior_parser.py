import json
import os

def load_logs(path=None):
    if path is None:
        path = os.path.expandvars(r"%LOCALAPPDATA%\\LibertyAgent\\logs\\agent_logs.json")
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return [json.loads(line) for line in f.readlines()]

def format_prompt_from_logs(logs):
    recent = logs[-5:]
    actions = "\n".join(f"- {log['timestamp']}: Focused on {log['active_window']}" for log in recent)
    return (
        "The user’s recent computer activity:\n"
        f"{actions}\n\n"
        "Generate Python automation logic that could assist this user based on their behavior."
    )
