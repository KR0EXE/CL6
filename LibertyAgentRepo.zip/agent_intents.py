def guess_intent(logs):
    if not logs:
        return "No recent activity."
    last = logs[-1]
    win = last.get("active_window", "Unknown")
    apps = set()
    for l in logs[-5:]:
        for p in l.get("open_processes", []):
            apps.add(p.lower())
    if "discord" in apps and "chrome" in apps:
        return "Checking messages and browsing."
    if "code" in win.lower() or "vscode" in win.lower():
        return "Working on code or development."
    return f"Interacting with: {win}"
