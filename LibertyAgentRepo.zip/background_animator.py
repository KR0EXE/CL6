import tkinter as tk
import random
from PIL import Image, ImageTk, ImageEnhance
import os

class AnimatedBackground:
    def __init__(self, canvas, width, height, skull_image_path):
        self.canvas = canvas
        self.width = width
        self.height = height
        self.skull_image_path = skull_image_path
        self.skulls = []
        self.load_image()
        self.running = True
        self.create_skulls()
        self.animate()

    def load_image(self):
        img = Image.open(self.skull_image_path).convert("RGBA")
        enhancer = ImageEnhance.Color(img)
        img = enhancer.enhance(2.0)
        self.original = img

    def create_skulls(self):
        for _ in range(10):
            size = random.randint(40, 100)
            img = self.original.resize((size, size), Image.LANCZOS)
            tk_img = ImageTk.PhotoImage(img)
            x = random.randint(0, self.width)
            y = random.randint(0, self.height)
            dx = random.choice([-1, 1]) * random.uniform(0.3, 1.2)
            dy = random.choice([-1, 1]) * random.uniform(0.3, 1.2)
            skull = self.canvas.create_image(x, y, image=tk_img, anchor=tk.CENTER)
            self.skulls.append({'id': skull, 'x': x, 'y': y, 'dx': dx, 'dy': dy, 'img': tk_img})

    def animate(self):
        if not self.running:
            return
        for s in self.skulls:
            s['x'] += s['dx']
            s['y'] += s['dy']
            if s['x'] < 0 or s['x'] > self.width:
                s['dx'] *= -1
            if s['y'] < 0 or s['y'] > self.height:
                s['dy'] *= -1
            self.canvas.coords(s['id'], s['x'], s['y'])
        self.canvas.after(30, self.animate)

def start_background(canvas, width, height, image_filename='skull.png'):
    image_path = os.path.join(os.path.dirname(__file__), image_filename)
    AnimatedBackground(canvas, width, height, image_path)
