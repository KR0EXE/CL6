import subprocess
import sys
import io
import traceback

def run_script(code):
    output = io.StringIO()
    try:
        exec(code, {'__builtins__': __builtins__}, {'print': lambda *args: print(*args, file=output)})
        return output.getvalue()
    except Exception:
        return traceback.format_exc()

def run_shell(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return f"Command: {command}\nExit Code: {result.returncode}\nOutput:\n{result.stdout}\nErrors:\n{result.stderr}"
    except Exception as e:
        return f"Shell execution failed: {str(e)}"
