def generate_python_automation(prompt):
    return f"""import os
import time

# Auto-generated script from agent
# Purpose: {prompt}
print('Running automation task: {prompt}')
"""