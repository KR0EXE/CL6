import json
from collections import defaultdict
from datetime import datetime

def detect_patterns(logs):
    app_sessions = defaultdict(list)
    for log in logs:
        timestamp = datetime.fromisoformat(log['timestamp'])
        for app in log['open_processes']:
            app_sessions[app].append(timestamp)

    patterns = {}
    for app, times in app_sessions.items():
        if len(times) < 2:
            continue
        durations = [(times[i+1] - times[i]).seconds for i in range(len(times)-1)]
        avg = sum(durations) / len(durations)
        patterns[app] = {"launch_count": len(times), "avg_interval_seconds": round(avg, 2)}
    return patterns
