import json
import os
import time

EDIT_QUEUE = "agent_edit_queue.json"
EDIT_LOG = "agent_edit_log.txt"

def apply_edit_safely(filepath, pattern, replacement):
    try:
        with open(filepath, "r") as f:
            content = f.read()
        if pattern not in content:
            return f"Pattern not found in {filepath}"
        new_content = content.replace(pattern, replacement)
        with open(filepath, "w") as f:
            f.write(new_content)
        with open(EDIT_LOG, "a") as log:
            log.write(f"EDITED {filepath}: replaced {pattern} → {replacement}\n")
        return "Edit applied successfully."
    except Exception as e:
        return f"Error during edit: {str(e)}"

def listen_for_file_edits(callback):
    while True:
        if os.path.exists(EDIT_QUEUE):
            try:
                with open(EDIT_QUEUE, "r") as f:
                    data = json.load(f)
                result = callback(data)
                os.remove(EDIT_QUEUE)
            except Exception as e:
                with open(EDIT_LOG, "a") as log:
                    log.write(f"[edit_listener] Error: {str(e)}\n")
        time.sleep(5)
