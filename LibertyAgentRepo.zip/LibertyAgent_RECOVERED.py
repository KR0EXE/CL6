import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import threading
import time
import os
import tkinter.simpledialog as sd
import json
from agent_core import log_snapshot
from behavior_parser import load_logs, format_prompt_from_logs
from executor import query_openai
from script_runner import run_script, run_shell

# Ensure safe logging path
LOG_PATH = os.path.expandvars(r"%LOCALAPPDATA%\\LibertyAgent\\logs\\agent_logs.json")
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)

QUEUE_FILE = "agent_queue.json"
OUTPUT_FILE = "agent_output.json"

def run_custom_logic(instruction):
    task = instruction.get("task")
    if task == "analyze_recent_activity":
        logs = load_logs()
        prompt = format_prompt_from_logs(logs[-5:])
        response = query_openai(prompt)
        return {"prompt": prompt, "response": response}
    elif task == "say":
        return {"message": instruction.get("message", "No message provided.")}
    else:
        return {"error": "Unknown task"}

def listen_for_instructions():
    while True:
        if os.path.exists(QUEUE_FILE):
            try:
                with open(QUEUE_FILE, "r") as f:
                    instruction = json.load(f)
                result = run_custom_logic(instruction)
                with open(OUTPUT_FILE, "w") as f:
                    json.dump(result, f, indent=2)
                os.remove(QUEUE_FILE)
            except Exception as e:
                with open(OUTPUT_FILE, "w") as f:
                    json.dump({"error": str(e)}, f)
        time.sleep(5)

class LibertyAgentUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Liberty Agent")
        self.root.geometry("800x600")

        self.prompt_box = ScrolledText(root, height=10, bg="#1e1e1e", fg="white")
        self.prompt_box.pack(fill="both", expand=False)

        self.response_box = ScrolledText(root, bg="black", fg="lime")
        self.response_box.pack(fill="both", expand=True)

        self.status_label = tk.Label(root, text="Status: Idle", anchor="w")
        self.status_label.pack(fill="x")

        self.run_button = tk.Button(root, text="Run Last Script", command=self.run_last_script)
        self.run_button.pack(fill="x")

        self.shell_button = tk.Button(root, text="Run Shell Command", command=self.run_shell_command)
        self.shell_button.pack(fill="x")

        self.command_button = tk.Button(root, text="Send Agent Command", command=self.send_agent_command)
        self.command_button.pack(fill="x")

        self.execution_output = ScrolledText(root, height=8, bg="#111", fg="cyan")
        self.execution_output.pack(fill="both", expand=False)

        self.run_loop()

    def run_last_script(self):
        try:
            code = self.response_box.get("1.0", tk.END)
            output = run_script(code)
            self.execution_output.delete("1.0", tk.END)
            self.execution_output.insert(tk.END, output)
        except Exception as e:
            self.execution_output.insert(tk.END, f"[ERROR in run_last_script]\n{e}\n")

    def run_shell_command(self):
        try:
            command = sd.askstring("Run Shell Command", "Enter a shell command:")
            if command:
                output = run_shell(command)
                self.execution_output.delete("1.0", tk.END)
                self.execution_output.insert(tk.END, output)
        except Exception as e:
            self.execution_output.insert(tk.END, f"[ERROR in run_shell_command]\n{e}\n")

    def send_agent_command(self):
        try:
            task = sd.askstring("Agent Task", "Enter task type (e.g. analyze_recent_activity or say):")
            if task:
                payload = {"task": task}
                if task == "say":
                    msg = sd.askstring("Say", "Message:")
                    if msg:
                        payload["message"] = msg

                with open(QUEUE_FILE, "w") as f:
                    json.dump(payload, f)
                time.sleep(6)
                if os.path.exists(OUTPUT_FILE):
                    with open(OUTPUT_FILE) as f:
                        result = json.load(f)
                    self.execution_output.insert(tk.END, f"\n>>> Agent Output:\n{json.dumps(result, indent=2)}\n{'-'*80}\n")
                    self.execution_output.see(tk.END)
        except Exception as e:
            self.execution_output.insert(tk.END, f"[ERROR in send_agent_command]\n{e}\n")

    def run_loop(self):
        def loop():
            while True:
                try:
                    log_snapshot(path=LOG_PATH)
                    logs = load_logs(path=LOG_PATH)
                    prompt = format_prompt_from_logs(logs)
                    self.prompt_box.delete("1.0", tk.END)
                    self.prompt_box.insert(tk.END, prompt)
                    self.status_label.config(text="Status: Querying GPT-4...")

                    response = query_openai(prompt)
                    self.response_box.insert(tk.END, f"\n>>> Response @ GPT-4:\n{response}\n{'-'*80}\n")
                    self.response_box.see(tk.END)
                    self.status_label.config(text="Status: Sleeping... (30s)")
                except Exception as e:
                    self.response_box.insert(tk.END, f"\n[ERROR in run_loop]\n{e}\n")
                time.sleep(30)

        threading.Thread(target=loop, daemon=True).start()

if __name__ == "__main__":
    try:
        print("STEP 1: Tk launch")
        root = tk.Tk()
        print("STEP 2: UI init")
        app = LibertyAgentUI(root)
        print("STEP 3: Listener started")
        threading.Thread(target=listen_for_instructions, daemon=True).start()
        print("STEP 4: Entering mainloop")
        root.mainloop()
    except Exception as e:
        with open("agent_crashlog.txt", "w") as f:
            f.write(f"[LibertyAgent_RECOVERED] Crash: {str(e)}\n")
